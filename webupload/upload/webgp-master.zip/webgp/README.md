# webgp 
webgp 是用来爬取google play 中的app info & detail

环境:
	1.[go]
	2.[go-query]


